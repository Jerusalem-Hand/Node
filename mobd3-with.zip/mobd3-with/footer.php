<?php global $lumise;
?>
<footer class="footer">
    <div class="container">
        <div class="footer_content">
            <a href="https://linkysoft.com/products/mobd3-product-designer-tool/" class="footer_logo"><img src="https://linkysoft.com/wp-content/uploads/logo-3.png"></a>
            <p>
                Add: cairo,egypt<br>
                Email: <a href="mailto:info@linkysoft.com" target="_blank">info@linkysoft.com</a><br>
                Help: <a href="https://linkysoft.com/kb/mobd3/" target="_blank">Help Mobd3</a>
            </p>
            <ul class="tsd_social">
                <li><a href="https://www.facebook.com/Linkysoft/" target="_blank" class="fa fa-facebook"></a></li>
                <li><a href="#" target="_blank" class="fa fa-twitter"></a></li>
                <li><a href="#" target="_blank" class="fa fa-instagram"></a></li>
            </ul>
        </div>
        <div class="footer_content">
            <h4>Custom care</h4>
            <ul class="link">
                <li><a href="https://linkysoft.com/about-us/">About Us</a></li>
                <li><a href="https://linkysoft.com/kb/mobd3/">Help Center</a></li>
                <li><a href="https://linkysoft.com/products/mobd3-product-designer-tool/">Features</a></li>
                <li><a href="https://linkysoft.com/products/mobd3-product-designer-tool/#pricing">Pricing</a></li>
            </ul>
        </div>
        <div class="footer_content">
            <h4>More</h4>
            <ul class="link">
                <li><a href="https://linkysoft.com/products/mobd3-product-designer-tool/#faqs">FAQs</a></li>
                <li><a href="#">Testimonial</a></li>
                <li><a href="https://linkysoft.com/products/call-us">Contact</a></li>
            </ul>
        </div>
        <div class="footer_content">
            <h4>Newsletter</h4>
            <p>Sign up our newsletter to receive updates from our store, promotions, and events.</p>
            <form action="" class="form-sub">
                <input type="text" placeholder="Email address here">
                <input type="submit" value="Send" class="rtl_submit">
            </form>
        </div>
    </div>
    <div class="container">
        <div class="copyright">
            <p>Copyright © 2019 <a href="https://linkysoft.com" target="_blank">linkysoft.com</a> | <a href="https://linkysoft.com/policies/privacy-policy">Privacy &amp; policy</a><a href="https://linkysoft.com/policies/Terms-of-use">Term of services</a></p>
        </div>
    </div>
</footer>
</body>
</html>